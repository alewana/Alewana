require('dotenv').config(); // Load environment variables from.env file

const TelegramBot = require('node-telegram-bot-api');
const sqlite3 = require('sqlite3').verbose();
const winston = require('winston');
const moment = require('moment');
const { NlpManager } = require('node-nlp'); // For NLU and NLG capabilities
const { SQLChatMessageHistory } = require('@langchain/community/chat_history/sqlite'); // For persistent chat history [5]

// === Configuration ===
const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_USER_ID = parseInt(process.env.ADMIN_USER_ID, 10); // Ensure it's an integer

if (!BOT_TOKEN |
| isNaN(ADMIN_USER_ID)) {
  console.error('Error: Missing or invalid environment variables. Please set BOT_TOKEN and ADMIN_USER_ID in your.env file.');
  process.exit(1);
}

// === Logging Configuration ===
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} - ${level.toUpperCase()} - ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'bot.log' }) // Log to file [6]
});

// === Database Setup ===
const DB_PATH = './bot.db';
const db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    logger.error(`Database error: ${err.message}`);
    process.exit(1);
  }
  logger.info('Connected to the SQLite database.');
});

// Initialize database tables [7, 8]
db.serialize(() => {
  // Table for explicit knowledge taught via!teach command and for RAG [1, 9, 10, 11, 12]
  db.run(`
    CREATE TABLE IF NOT EXISTS knowledge_base (
      question TEXT PRIMARY KEY,
      answer TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      usage_count INTEGER DEFAULT 0
    )
  `);

  // Table for general conversation logs
  db.run(`
    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT,
      message TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Table for user information (e.g., admin status, preferences) [7, 13]
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      user_id INTEGER PRIMARY KEY,
      username TEXT,
      first_name TEXT,
      last_name TEXT,
      is_admin BOOLEAN DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Table for LangChain's SQLChatMessageHistory (for context management) [14, 5]
  db.run(`
    CREATE TABLE IF NOT EXISTS chat_histories (
      session_id TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (session_id, created_at)
    )
  `);
});

// === NLU Manager Setup ===
// forceNER: true enables Named Entity Recognition
const nlpManager = new NlpManager({ languages: ['en'], forceNER: true, nlu: { useNoneFeature: false } }); // useNoneFeature: false to avoid "None" intent for unseen words

// Default knowledge for initial NLU training and fallback [12]
const DEFAULT_KNOWLEDGE = {
  "who are you": "I am SormGPT, your helpful AI assistant.",
  "who is your developer": "@l9shx is my developer.",
  "hello": "Hello! How can I help you today?",
  "hi": "Hi there! What can I do for you?",
  "help": "You can ask me anything or teach me new things using:\n\n`!teach question | answer` (Admin only)\n\nI can also try to 'search the web' or 'find information about' something for you.",
  "what can you do": "I can answer your questions based on what I've learned, and I can also simulate a web search for you. You can teach me new things too!",
  "search the web for": "I can perform a simulated web search for you. What would you like to search for?",
  "find information about": "I can simulate finding information for you. What topic are you interested in?",
};

async function trainNlpManager() {
  logger.info('Training NLU manager...');
  // Clear existing documents and answers to retrain from scratch
  // This ensures the model is always up-to-date with the latest knowledge_base entries.
  nlpManager.removeCorpus();

  // Add default knowledge to NLU manager
  for (const question in DEFAULT_KNOWLEDGE) {
    nlpManager.addDocument('en', question, `default.${question.replace(/\s/g, '_')}`);
    nlpManager.addAnswer('en', `default.${question.replace(/\s/g, '_')}`, DEFAULT_KNOWLEDGE[question]);
  }

  // Load explicitly taught knowledge from the 'knowledge_base' table for NLU training [1, 9, 10, 11, 12]
  db.all("SELECT question, answer FROM knowledge_base", (err, rows) => {
    if (err) {
      logger.error(`Error loading knowledge_base for NLU training: ${err.message}`);
      return;
    }
    rows.forEach(row => {
      // Add both question and answer as documents to improve understanding of patterns [10, 15]
      // This helps the bot "understand" and "analyze" by recognizing patterns in both inputs and outputs.
      const intentName = `taught.${row.question.replace(/\s/g, '_').toLowerCase()}`;
      nlpManager.addDocument('en', row.question, intentName);
      nlpManager.addAnswer('en', intentName, row.answer);
      // Also add the answer as a document to help it recognize related concepts in user queries
      nlpManager.addDocument('en', row.answer, intentName);
    });

    // Train the NLU model
    (async () => {
      await nlpManager.train();
      // nlpManager.save(); // In a production environment, you might save the model to a file and load it
      logger.info('NLU manager trained successfully.');
    })();
  });
}

// Train NLU manager on startup
trainNlpManager();

// === Database Functions ===
function saveLog(userId, username, message) {
  db.run(
    "INSERT INTO logs (user_id, username, message) VALUES (?,?,?)",
    [userId, username, message],
    (err) => {
      if (err) {
        logger.error(`Error saving log: ${err.message}`);
      }
    }
  );
}

function saveUser(user_id, username, first_name, last_name, is_admin, callback) {
  db.run(
    "INSERT OR REPLACE INTO users (user_id, username, first_name, last_name, is_admin) VALUES (?,?,?,?,?)",
    [user_id, username, first_name, lastName, is_admin? 1 : 0],
    (err) => {
      if (err) {
        logger.error(`Error saving user: ${err.message}`);
        return callback(false);
      }
      callback(true);
    }
  );
}

function teachQuestion(question, answer, callback) {
  // Save to 'knowledge_base' for explicit learning and NLU training [1, 9, 11, 12]
  db.run(
    "INSERT OR REPLACE INTO knowledge_base (question, answer, usage_count) VALUES (?,?, COALESCE((SELECT usage_count FROM knowledge_base WHERE question =?), 0))",
    [question.toLowerCase().trim(), answer.trim(), question.toLowerCase().trim()],
    (err) => {
      if (err) {
        logger.error(`Error teaching question to knowledge_base: ${err.message}`);
        return callback(false);
      }
      // Retrain NLU manager to incorporate new knowledge [1, 9, 11, 12]
      trainNlpManager();
      callback(true);
    }
  );
}

// Function to retrieve relevant context from knowledge_base (simplified RAG retrieval) [16, 17, 18, 3]
// This simulates semantic search using LIKE queries. For true semantic search,
// sqlite-vec would be used with embeddings.
async function getKnowledgeBaseContext(query) {
  return new Promise((resolve, reject) => {
    const searchTerms = query.toLowerCase().split(/\s+/).filter(term => term.length > 2).map(term => `%${term}%`);
    if (searchTerms.length === 0) return resolve(null);

    const whereClause = searchTerms.map(() => "question LIKE? OR answer LIKE?").join(" OR ");
    const params = searchTerms.flatMap(term => [term, term]);

    db.all(
      `SELECT question, answer FROM knowledge_base WHERE ${whereClause} ORDER BY usage_count DESC LIMIT 3`,
      params,
      (err, rows) => {
        if (err) {
          logger.error(`Error retrieving knowledge base context: ${err.message}`);
          return reject(err);
        }
        if (rows.length > 0) {
          const context = rows.map(row => `Q: ${row.question}\nA: ${row.answer}`).join('\n---\n');
          return resolve(context);
        }
        resolve(null);
      }
    );
  });
}

// === Bot Setup ===
const bot = new TelegramBot(BOT_TOKEN, { polling: true });

// === Command Handlers ===
function handleHelp(msg) {
  const helpText = `
🤖 <b>SormGPT Help</b> 🤖

You can interact with me in these ways:

• Ask me any question (e.g., "What is the capital of France?")
• Teach me new things with:
  <code>!teach question | answer</code> (Admin only)
• View stats with:
  <code>!stats</code>

I'll do my best to help you!
`;
  bot.sendMessage(msg.chat.id, helpText, { parse_mode: 'HTML' });
}

function handleStats(msg) {
  db.serialize(() => {
    db.get("SELECT COUNT(*) as count FROM knowledge_base", (err, kbRow) => {
      if (err) {
        logger.error(`Error getting knowledge base count: ${err.message}`);
        return bot.sendMessage(msg.chat.id, "❌ Could not retrieve statistics.");
      }

      db.get("SELECT COUNT(*) as count FROM logs", (err, logRow) => {
        if (err) {
          logger.error(`Error getting log count: ${err.message}`);
          return bot.sendMessage(msg.chat.id, "❌ Could not retrieve statistics.");
        }

        let statsText = `
📊 <b>Bot Statistics</b>

• Knowledge Base entries: ${kbRow.count}
• Total interactions: ${logRow.count}

<b>Top Questions (from Knowledge Base):</b>
`;

        db.all(
          "SELECT question, usage_count FROM knowledge_base ORDER BY usage_count DESC LIMIT 5",
          (err, topQuestions) => {
            if (err) {
              logger.error(`Error getting top questions: ${err.message}`);
              return bot.sendMessage(msg.chat.id, "❌ Could not retrieve statistics.");
            }

            if (topQuestions.length === 0) {
              statsText += "\nNo top questions yet.";
            } else {
              topQuestions.forEach((q, i) => {
                statsText += `\n${i+1}. ${q.question} (used ${q.usage_count} times)`;
              });
            }

            bot.sendMessage(msg.chat.id, statsText, { parse_mode: 'HTML' });
          }
        );
      });
    });
  });
}

// Simulated Web Search Function
async function performSimulatedWebSearch(query) {
  logger.info(`Simulating web search for: "${query}"`);
  // In a real scenario, you would integrate with a non-OpenAI search API here,
  // e.g., Google Custom Search API, News API [19, 20], or a specific data API.[18, 21, 2]
  // The response would then need to be parsed and summarized by your NLU/NLG.
  await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate network delay

  const simulatedResults =;

  const relevantResult = simulatedResults.find(result => result.toLowerCase().includes(query.toLowerCase())) ||
                       simulatedResults;

  return `
🌐 <b>Simulated Web Search Results for "${query}"</b>

Here's what I found:
${relevantResult}

<i>Source: Simulated Internet Knowledge Base</i>
`;
}

// === Message Handler ===
async function handleMessage(msg) {
  if (!msg.text) return;

  const message = msg.text.trim();
  const user = msg.from;
  const userId = user.id;
  const username = user.username |
| "Unknown";
  const firstName = user.first_name |
| "";
  const lastName = user.last_name |
| "";
  const chatId = msg.chat.id;

  saveLog(userId, username, message);
  saveUser(userId, username, firstName, lastName, userId === ADMIN_USER_ID, (success) => {
    if (!success) logger.warn(`Failed to save user ${username} (${userId})`);
  });

  // Get chat history for the current session (for context management) [14, 22, 23, 5, 24]
  const chatHistory = new SQLChatMessageHistory({
    sessionId: chatId.toString(), // Use chat ID as session ID
    connectionString: `sqlite://${DB_PATH}`,
    tableName: 'chat_histories'
  });

  // Add user message to history
  // SQLChatMessageHistory expects BaseMessage types, which are part of LangChain Core.
  // We'll use simple objects that mimic them for storage.
  await chatHistory.addMessage({ type: 'human', content: message });

  // TEACH MODE
  if (message.startsWith("!teach")) {
    if (userId!== ADMIN_USER_ID) {
      return bot.sendMessage(chatId, "🚫 You are not authorized to use the `!teach` command.");
    }

    try {
      const data = message.substring(6).trim();
      const parts = data.split("|").map(s => s.trim());

      if (parts.length < 2 ||!parts ||!parts[1]) {
        return bot.sendMessage(chatId, "❌ Invalid format. Use: `!teach question | answer`");
      }

      const question = parts;
      const answer = parts[1];

      if (DEFAULT_KNOWLEDGE[question.toLowerCase()]) {
        return bot.sendMessage(chatId, "This is built-in knowledge and cannot be changed.");
      }

      teachQuestion(question, answer, async (success) => {
        if (success) {
          await bot.sendMessage(chatId, `✅ Understood! I've added this to my knowledge base.`);
          // Simulate "analysis" and "self-development" by immediately demonstrating understanding
          setTimeout(async () => {
            const analyzedResponse = `Based on what you just taught me, I now know that "${question}" can be answered with "${answer}". I'll remember this for future conversations!`;
            await bot.sendMessage(chatId, analyzedResponse);
            await chatHistory.addMessage({ type: 'ai', content: analyzedResponse });
          }, 1500); // Small delay to simulate processing
        } else {
          bot.sendMessage(chatId, "❌ Failed to save the knowledge. Please try again.");
        }
      });
    } catch (err) {
      logger.error(`Error in teach mode: ${err.message}`);
      bot.sendMessage(chatId, "❌ An error occurred while processing your request.");
    }
    return;
  }

  try {
    // 1. NLU for Intent and Entity Recognition
    const nluResult = await nlpManager.process('en', message);
    const intent = nluResult.intent;
    const score = nluResult.score;
    const entities = nluResult.entities;

    logger.info(`NLU Result: Intent=${intent}, Score=${score}, Entities=${JSON.stringify(entities)}`);

    let botResponseContent = null;

    // Check for specific intents or keywords to trigger simulated web search
    const webSearchTriggers = [
      'search the web for', 'find information about', 'what is', 'tell me about', 'how does', 'explain'
    ];
    const isWebSearchQuery = webSearchTriggers.some(trigger => message.toLowerCase().includes(trigger)) ||
                             (intent && (intent.startsWith('default.search_the_web_for') |
| intent.startsWith('default.find_information_about')));

    if (isWebSearchQuery) {
      const searchQuery = message.toLowerCase().replace(/^(search the web for|find information about|what is|tell me about|how does|explain)\s*/, '').trim();
      botResponseContent = await performSimulatedWebSearch(searchQuery |
| "general topics");
    } else if (score > 0.75 && nluResult.answer) { // High confidence NLU answer from taught or default knowledge
      botResponseContent = nluResult.answer;
      // Increment usage count for the question if it came from knowledge_base [1, 12]
      if (intent && intent.startsWith('taught.')) {
        const originalQuestion = intent.substring('taught.'.length).replace(/_/g, ' ');
        db.run("UPDATE knowledge_base SET usage_count = usage_count + 1 WHERE question =?", [originalQuestion], (err) => {
          if (err) logger.error(`Error updating usage count for ${originalQuestion}: ${err.message}`);
        });
      }
    } else {
      // Attempt to retrieve context from knowledge base for more nuanced responses (simplified RAG) [16, 17, 18, 3]
      const retrievedContext = await getKnowledgeBaseContext(message);
      if (retrievedContext) {
        logger.info('Retrieved internal knowledge base context for general query.');
        // For a non-LLM bot, we'd need a more sophisticated NLG here to combine context.
        // For now, we'll just append it or use a generic response.
        botResponseContent = `Based on what I've learned, here's some relevant information:\n\n${retrievedContext}\n\nIs there anything else I can help with?`;
      } else {
        // Fallback if no specific intent or relevant context found
        botResponseContent = "I don't know the answer to that. You can teach me using:\n\n" +
          "<code>!teach question | answer</code>\n\n" +
          "Or try asking me to 'search the web for...' something.";
      }
    }

    if (botResponseContent) {
      bot.sendMessage(chatId, botResponseContent, { parse_mode: 'HTML' });
      await chatHistory.addMessage({ type: 'ai', content: botResponseContent }); // Save bot's response to history
    }

  } catch (error) {
    logger.error(`Error processing message: ${error.message}`, error.stack);
    bot.sendMessage(chatId, "❌ An error occurred while processing your request. Please try again later.");
  }
}

// === Bot Event Listeners ===
bot.onText(/\/help/, handleHelp);
bot.onText(/\/stats/, handleStats);
bot.on('message', (msg) => {
  // Ignore commands handled by onText or messages without text
  if (msg.text &&!msg.text.startsWith('/') &&!msg.text.startsWith('!teach')) {
    handleMessage(msg);
  } else if (msg.text && msg.text.startsWith('!teach')) {
    handleMessage(msg); // Handle!teach command through the main handler
  }
});

// === Startup Message ===
logger.info('🤖 SormGPT is starting...');
bot.on('polling_error', (error) => {
  logger.error(`Polling error: ${error.message}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  logger.info('Bot shutting down...');
  db.close((err) => {
    if (err) {
      logger.error(`Error closing database: ${err.message}`);
    } else {
      logger.info('Database connection closed.');
    }
    process.exit();
  });
});
